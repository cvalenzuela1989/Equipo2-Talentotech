# InnovaLab - API Backend

Backend service for the InnovaLab platform (Team 2), developed in Spring Boot using Java.

The execution environment is completely containerized, meaning that **there is no need to have the programs installed locally** to run the application.

---

## Prerequisites (Minimum)

To clone and run the project as cleanly as possible, you will need:

1. **Docker**.
2. **Docker Compose**.
3. **Git**.

---

## Initialization with Docker

### Clone the repository

```sh
# Clone repository
git clone <repo>

# Go to repository
cd api-spring-boot
```

### Configure environment variables

The container requires certain variables in memory to start. You must create a local file from the template:

```sh
cp .env.example .env
```

Open the created `.env` file and define the necessary values, for example: `PORT=3000`.

### Spin up the ecosystem

Execute in the root of the project:

```sh
# Run application in the background
docker compose up -d --build
```

## Useful Docker Compose commands

| **Action**       | **Command**              | **Description**                                                         |
| ---------------- | ------------------------ | ----------------------------------------------------------------------- |
| **View logs**    | `docker compose logs -f` | Show console output and requests in real time                           |
| **Check status** | `docker compose ps`      | Verifies that the container is running and the port is correctly mapped |
| **Restart**      | `docker compose restart` | Safely restarts the application services                                |
| **Stop**         | `docker compose down`    | Stops and removes the container, freeing up system memory               |

---

## Use automation script

To run an automation script, you can use `build.sh` on Linux/MacOS or `build.ps1` on Windows.

### On Linux/MacOS

You must grant execution permissions to the file:

```sh
chmod +x build.sh
```

Run the script:

```sh
./build.sh
```

To stop the execution and free up the used port, press **CTRL + C**.

### On Windows

You must grant execution permissions to the file:

```sh
PowerShell -ExecutionPolicy Bypass -File .\build.ps1
```

Run the script:

```sh
./build.ps1
```

To stop the execution and free up the used port, press **CTRL + C**.

---

## Local development environment (optional)

To develop the project natively on your machine (without using Docker), **Java 25 (JDK)** is required. The project uses the Gradle Wrapper (`./gradlew`), so it is not necesarry to install Gradle globally.

### Available Gradle commands and tasks

- `./gradlew bootRun`: Starts the local embedded development server (Tomcat) on the configured port. Thanks to `Spring Boot DevTools`, compiling the project will trigger a _hot-reload_.
- `./gradlew spotlessApply`: Applies strict formatting to all Java source code following the official **Google Java Format** rules.
- `./gradlew spotlessCheck`: Validates that code style rigorously complies with standards before pusing changes (linter-like).
- `./gradlew test`: Runs the unit and integration test suite using **JUnit 6** along with **Testcontainers** to isolate PostgreSQL integration tests.
- `./gradlew jacocoTestReport`: Generates a comprehensive mathematical code coverage report.

---

## Main tech stack

- **Runtime**: Java 25 (Eclipse Temurin / Alpine Linux for the optimized container).
- **Framework**: Spring Boot 4.0.x (Spring WebMVC).
- **Persistence**: Spring Data JPA with Hibernate and PostgreSQL driver.
- **Security and telemetry**: Spring Security (stateless configurations for REST APIs) and Spring Boot Actuator for auditing, metrics, and health status (`/actuator/health`).
- **Linter and formatter**: Spotless with Gradle plugin for automated code validation.
- **Testing**: JUnit 6, MockMvc, and Tescontainers (PostgreSQL).
