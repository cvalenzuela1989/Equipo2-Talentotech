# InnovaLab - API Backend

Servicio de backend para la plataforma de InnovaLab (Equipo 2), desarrollado en Spring Boot utilizando Java.

El entorno de ejecución está completamente contenerizado, lo que significa que **no se necesita tener instalado los programas localmente** para ejecutar la aplicación.

---

## Requisitos previos (Mínimos)

Para clonar y ejecutar el proyecto de la forma más limpia posible, se necesita:

1. **Docker**.
2. **Docker Compose**.
3. **Git**.

---

## Inicialización con Docker

### Clonar el repositorio

```sh
# Clonar repositorio
git clone <repo>

# Ir al repositorio
cd api-spring-boot
```

### Configurar variables de entorno

El contenedor requiere ciertas variables en memoria para iniciar. Se debe crear un archivo local a partir de la plantilla:

```sh
cp .env.example .env
```

Se abre el archivo `.env` creado y se definen los valores necesarios, por ejemplo `PORT=3000`.

### Levantar el ecosistema

Ejecutar en la raíz del proyecto:

```sh
# Ejecutar aplicación en segundo plano
docker compose up -d --build
```

## Comandos útiles de Docker Compose

| **Acción**     | **Comando**              | **Descripción**                                                     |
| -------------- | ------------------------ | ------------------------------------------------------------------- |
| **Ver logs**   | `docker compose logs -f` | Muestra la salida de consola y peticiones de Express en tiempo real |
| **Ver estado** | `docker compose ps`      | Verifica que el contenedor esté corriendo y el puerto bien mapeado  |
| **Reiniciar**  | `docker compose restart` | Reinicia de forma segura los servicios de la aplicación             |
| **Apagar**     | `docker compose down`    | Apaga y remueve el contenedor, liberando la memoria del equipo      |

---

## Usar script de automatización

Para ejecutar un script de automatización se pueden utilizar `build.sh` en Linux/MacOS o `build.ps1` en Windows.

### En Linux/MacOS

Se le deben dar permisos de ejecución al archivo:

```sh
chmod +x build.sh
```

Se ejecuta el script:

```sh
./build.sh
```

Para cortar la ejecución y liberar el puerto usado se debe presionar **CTRL + C**.

### En Windows

Se le deben dar permisos de ejecución al archivo:

```sh
PowerShell -ExecutionPolicy Bypass -File .\build.ps1
```

Se ejecuta el script:

```sh
./build.ps1
```

Para cortar la ejecución y liberar el puerto usado se debe presionar **CTRL + C**.

---

## Entorno de desarrollo local (opcional)

Para desarrollar el proyecto de forma nativa en el equipo (sin usar Docker), se requiere tener instalado **Java 25 (JDK)**. El proyecto utiliza el Gradle Wrapper (`./gradlew`), por lo que no es necesario instalar Gradle globalmente.

### Comandos y tareas disponibles de Gradle

- `./gradlew bootRun`: Levanta el servidor de desarrollo local embebido (Tomcat) en el puerto configurado. Gracias a `Spring Boot DevTools`, compilar el proyecto va a aplicar _hot-reload_.
- `./gradlew spotlessApply`: Aplica un formateo estricto sobre todo el código fuente Java siguiendo las reglas oficiales de **Google Java Format**.
- `./gradlew spotlessCheck`: Valida que el estilo del código cumpla rigurosamente con los estándares antes de subir cambios (linter-like).
- `./gradlew test`: Ejecuta la suite de pruebas unitarias e integradas utilizando **JUnit 6** junto con **Testcontainers** para aislar los tests de integración de PostgreSQL.
- `./gradlew jacocoTestReport`: Genera un reporte matemático completo de cobertura de código.

---

## Stack tecnológico principal

- **Runtime**: Java 25 (Eclipse Temurin / Alpine Linux para el contenedor optimizado).
- **Framework**: Spring Boot 4.0.x (Spring WebMVC).
- **Persistencia**: Spring Data JPA con Hibernate y driver de PostgreSQL.
- **Seguridad y telemetría**: Spring Security (configuraciones stateless para REST APIs) y Spring Boot Actuator para auditoría, métricas y estado de salud (`/actuator/health`).
- **Linter y formateador**: Spotless con plugin Gradle para validación automática de código.
- **Testing**: JUnit 6, MockMvc y Testcontainers (PostgreSQL).
