plugins {
    java
    id("org.springframework.boot") version "4.0.6"
    id("io.spring.dependency-management") version "1.1.7"
    id("com.diffplug.spotless") version "8.5.1"
    id("org.jetbrains.gradle.plugin.idea-ext") version "1.4.1"
    jacoco
}

group = "com.innovalab.team.2"
version = "0.0.1-SNAPSHOT"

java {
    toolchain {
        languageVersion = JavaLanguageVersion.of(25)
    }
}

repositories {
    mavenCentral()
}

plugins.withType<com.diffplug.gradle.spotless.SpotlessPlugin> {
    configure<com.diffplug.gradle.spotless.SpotlessExtension> {
        java {
            target("src/**/*.java")
            googleJavaFormat("1.35.0")
            removeUnusedImports()
            endWithNewline()
        }
    }
}

dependencies {
    implementation("org.springframework.boot:spring-boot-starter-actuator")
    implementation("org.springframework.boot:spring-boot-starter-data-jpa")
    implementation("org.springframework.boot:spring-boot-starter-security")
    implementation("org.springframework.boot:spring-boot-starter-webmvc")
    compileOnly("org.projectlombok:lombok")
    runtimeOnly("org.postgresql:postgresql")
    annotationProcessor("org.projectlombok:lombok")
    testImplementation("org.springframework.boot:spring-boot-starter-actuator-test")
    testImplementation("org.springframework.boot:spring-boot-starter-data-jpa-test")
    testImplementation("org.springframework.boot:spring-boot-starter-security-test")
    testImplementation("org.springframework.boot:spring-boot-starter-webmvc-test")
    testImplementation("org.springframework.boot:spring-boot-testcontainers")
    testImplementation("org.testcontainers:testcontainers-junit-jupiter")
    testImplementation("org.testcontainers:testcontainers-postgresql")
    testCompileOnly("org.projectlombok:lombok")
    testRuntimeOnly("org.junit.platform:junit-platform-launcher")
    testAnnotationProcessor("org.projectlombok:lombok")
}

tasks.withType<Test> {
    useJUnitPlatform()
}

tasks.register("installLocalGitHooks") {
    description = "Installs local Git hooks natively"
    group = "build setup"
    doLast {
        val hookFile = project.file("${rootProject.projectDir}/.git/hooks/pre-commit")
        val hookContent = $$"""
            #!/bin/sh
            echo "============================================="
            echo "Running strict code quality checks (Spotless)"
            echo "============================================="
            ./gradlew spotlessCheck --no-daemon
            status=$?
            if [ $status -ne 0 ]; then
                echo "Error: Code formatting or style violations found."
                echo "Please run './gradlew spotlessApply' to automatically fix issues before committing."
                exit 1
            fi
            echo "Code style is spotless. Proceeding with commit..."
        """.trimIndent()
        hookFile.parentFile.mkdirs()
        hookFile.writeText(hookContent)
        hookFile.setExecutable(true)
    }
}

tasks.compileJava {
    dependsOn("installLocalGitHooks")
}
