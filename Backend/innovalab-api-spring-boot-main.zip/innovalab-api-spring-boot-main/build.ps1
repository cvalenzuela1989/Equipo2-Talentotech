$ErrorActionPreference = "Stop"

$portProcess = Get-NetTCPConnection -LocalPort 8080 -ErrorAction SilentlyContinue
if ($portProcess) {
    Write-Host "Releasing port 8080..." -ForegroundColor Yellow
    Stop-Process -Id $portProcess.OwningProcess -Force -ErrorAction SilentlyContinue
}
docker compose down 2>$null

Write-Host "Formatting and checking code..." -ForegroundColor Cyan
.\gradlew.bat spotlessApply --no-daemon
.\gradlew.bat test --no-daemon

Write-Host "Building and starting container..." -ForegroundColor Cyan
docker compose up -d --build

try {
    docker compose logs -f
} finally {
    Write-Host "`nTurning off container..." -ForegroundColor Yellow
    docker compose down
}