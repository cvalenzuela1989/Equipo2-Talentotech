#!/usr/bin/env bash

set -e
set -x

fuser -k 8080/tcp || true

docker compose down || true

chmod +x gradlew

./gradlew spotlessApply --no-daemon

./gradlew spotlessCheck --no-daemon

./gradlew test --no-daemon

docker compose up -d --build

trap 'docker compose down; exit 0' INT

docker compose logs -f