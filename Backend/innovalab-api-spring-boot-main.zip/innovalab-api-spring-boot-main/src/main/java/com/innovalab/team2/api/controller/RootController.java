package com.innovalab.team2.api.controller;

import com.innovalab.team2.api.dto.MessageResponse;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class RootController {
  @GetMapping("/")
  public ResponseEntity<MessageResponse> getRoot() {
    MessageResponse response = new MessageResponse("API is running", "success");
    IO.println("Response send");
    return ResponseEntity.ok(response);
  }
}
