package com.innovalab.team2.api.dto;

public record MessageResponse(String message, String status) {}
